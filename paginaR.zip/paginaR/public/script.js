function buscarReporte() {
    const reportId = document.getElementById("reportId").value;
    const resultadoDiv = document.getElementById("resultado");

    if (!reportId) {
        alert("Por favor, ingrese un número de reporte.");
        return;
    }

    fetch(`http://localhost:3000/report/${reportId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("Reporte no encontrado");
            }
            return response.json();
        })
        .then(data => {
            resultadoDiv.innerHTML = `
                <p><strong>#️⃣ Número de Reporte:</strong> ${data["Número de Reporte"]}</p>
                <p><strong>👤 Nombre:</strong> ${data["NOMBRE DE QUIEN REPORTA"]}</p>
                <p><strong>📍 Ubicación:</strong> ${data["UBICACION DEL REPORTE Y REFERENCIA"]}</p>
                <p><strong>📄 Dia del Reporte :</strong> ${data["DIA DEL REPORTE"]}</p>
                <h3><p><strong>✅ Estado:</strong> ${data["Estado"]}</p></h3>
            `;
            resultadoDiv.style.display = "block"; // Mostrar resultados
        })
        .catch(error => {
            resultadoDiv.innerHTML = `<p style="color: red;">❌ ${error.message}</p>`;
            resultadoDiv.style.display = "block";
        });
}
