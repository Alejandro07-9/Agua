const express = require('express');
const cors = require('cors'); // Importa cors
const axios = require('axios');
const csvParser = require('csv-parser');
const { Readable } = require('stream');
const os = require('os'); // Para obtener la IP local

const app = express();
const PORT = 3000;

// Configurar CORS
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(express.static('public')); // Asegúrate de que la carpeta "public" existe

// Configurar Content Security Policy (CSP)
app.use((req, res, next) => {
    res.setHeader("Content-Security-Policy", 
        "default-src 'self' https://www.gstatic.com https://fonts.googleapis.com; " +
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.gstatic.com; " +
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://www.gstatic.com; " +
        "img-src 'self' data: https://www.gstatic.com;");
    
    next();
});

const SHEET_URL = 'https://docs.google.com/spreadsheets/d/1roDHFMgbkO_bYQ52xLGpgx-Cg6N50tO5kIHjq9lTm-E/gviz/tq?tqx=out:csv';

// Endpoint para consultar un reporte por ID
app.get('/report/:id', async (req, res) => {
    try {
        const response = await axios.get(SHEET_URL);
        const data = response.data;
        
        const reports = [];
        const stream = Readable.from(data);
        
        stream.pipe(csvParser())
            .on('data', (row) => {
                const formattedRow = {};
                Object.keys(row).forEach(key => {
                    formattedRow[key.trim()] = row[key]; // Eliminar espacios en nombres de columnas
                });
                reports.push(formattedRow);
            })
            .on('end', () => {
                const report = reports.find(r => r['Número de Reporte'] == req.params.id);
                if (report) {
                    res.json(report);
                } else {
                    res.status(404).json({ message: 'Reporte no encontrado' });
                }
            });
        
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener los reportes', error: error.message });
    }
});

// Obtener la IP local
function getLocalIP() {
    const interfaces = os.networkInterfaces();
    for (let iface of Object.values(interfaces)) {
        for (let config of iface) {
            if (config.family === 'IPv4' && !config.internal) {
                return config.address;
            }
        }
    }
    return '127.0.0.1';
}

// Iniciar servidor en 0.0.0.0
app.listen(PORT, '0.0.0.0', () => {
    const localIP = getLocalIP();
    console.log(`Servidor en http://localhost:${PORT}`);
    console.log(`Accede desde otro dispositivo en: http://${localIP}:${PORT}`);
});
